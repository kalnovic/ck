<?php
// config.php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root'); // Nahraďte skutočným používateľským menom
define('DB_PASSWORD', 'root'); // Nahraďte skutočným heslom
define('DB_NAME', 'ck'); // Nahraďte názvom vašej databázy
?>
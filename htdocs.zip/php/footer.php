<!-- footer.php -->
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025</p>
    </footer>
</body>
</html>